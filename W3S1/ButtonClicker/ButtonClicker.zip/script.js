function goneBtn(element)  {
    element.remove();
}
function login(element) {
    element.innerText="Logout";
}
