function like(id) {
    document.querySelector(id).innerText++
}